VERSION = (5, 0, 1)
__version__ = ".".join(str(i) for i in VERSION)
